import React, { useState, useEffect } from 'react';
import { Container, Nav, Tab, Button } from 'react-bootstrap';
import CreaturesTab from './components/CreaturesTab';
import BattleTab from './components/BattleTab';
import PlayersTab from './components/PlayersTab';
import InitiativeDialog from './components/InitiativeDialog';

function App() {
  // Initialize state with localStorage values
  const [creatures, setCreatures] = useState(() => {
    try {
      const savedCreatures = localStorage.getItem('creatures');
      return savedCreatures ? JSON.parse(savedCreatures) : [];
    } catch (error) {
      console.error('Error loading creatures from localStorage:', error);
      return [];
    }
  });

  const [battleCreatures, setBattleCreatures] = useState(() => {
    try {
      const savedBattleCreatures = localStorage.getItem('battleCreatures');
      return savedBattleCreatures ? JSON.parse(savedBattleCreatures) : [];
    } catch (error) {
      console.error('Error loading battle creatures from localStorage:', error);
      return [];
    }
  });

  const [players, setPlayers] = useState(() => {
    try {
      const savedPlayers = localStorage.getItem('players');
      return savedPlayers ? JSON.parse(savedPlayers) : [];
    } catch (error) {
      console.error('Error loading players from localStorage:', error);
      return [];
    }
  });

  const [battleParticipants, setBattleParticipants] = useState(() => {
    try {
      const savedBattleParticipants = localStorage.getItem('battleParticipants');
      return savedBattleParticipants ? JSON.parse(savedBattleParticipants) : [];
    } catch (error) {
      console.error('Error loading battle participants from localStorage:', error);
      return [];
    }
  });

  const [currentTurn, setCurrentTurn] = useState(() => {
    try {
      const savedCurrentTurn = localStorage.getItem('currentTurn');
      return savedCurrentTurn || null;
    } catch (error) {
      console.error('Error loading current turn from localStorage:', error);
      return null;
    }
  });

  const [battleStarted, setBattleStarted] = useState(() => {
    try {
      const savedBattleStarted = localStorage.getItem('battleStarted');
      return savedBattleStarted === 'true';
    } catch (error) {
      console.error('Error loading battle started state from localStorage:', error);
      return false;
    }
  });

  const [currentRound, setCurrentRound] = useState(() => {
    try {
      const savedRound = localStorage.getItem('currentRound');
      return savedRound ? parseInt(savedRound) : 1;
    } catch (error) {
      console.error('Error loading current round from localStorage:', error);
      return 1;
    }
  });

  const [currentTab, setCurrentTab] = useState('battle');
  const [initiativeDialogOpen, setInitiativeDialogOpen] = useState(false);
  const [remainingParticipants, setRemainingParticipants] = useState([]);

  // Add state for initiative tie during start battle
  const [initiativeTie, setInitiativeTie] = useState(null);
  const [pendingInitiativeParticipant, setPendingInitiativeParticipant] = useState(null);

  // Save to localStorage whenever state changes
  useEffect(() => {
    try {
      localStorage.setItem('creatures', JSON.stringify(creatures));
    } catch (error) {
      console.error('Error saving creatures to localStorage:', error);
    }
  }, [creatures]);

  useEffect(() => {
    try {
      localStorage.setItem('battleCreatures', JSON.stringify(battleCreatures));
    } catch (error) {
      console.error('Error saving battle creatures to localStorage:', error);
    }
  }, [battleCreatures]);

  useEffect(() => {
    try {
      localStorage.setItem('players', JSON.stringify(players));
    } catch (error) {
      console.error('Error saving players to localStorage:', error);
    }
  }, [players]);

  useEffect(() => {
    try {
      localStorage.setItem('battleParticipants', JSON.stringify(battleParticipants));
    } catch (error) {
      console.error('Error saving battle participants to localStorage:', error);
    }
  }, [battleParticipants]);

  useEffect(() => {
    try {
      localStorage.setItem('currentTurn', currentTurn);
    } catch (error) {
      console.error('Error saving current turn to localStorage:', error);
    }
  }, [currentTurn]);

  useEffect(() => {
    try {
      localStorage.setItem('battleStarted', battleStarted);
    } catch (error) {
      console.error('Error saving battle started state to localStorage:', error);
    }
  }, [battleStarted]);

  useEffect(() => {
    try {
      localStorage.setItem('currentRound', currentRound);
    } catch (error) {
      console.error('Error saving current round to localStorage:', error);
    }
  }, [currentRound]);

  const handleTabChange = (key) => {
    setCurrentTab(key);
  };

  const handleAddCreature = (creature) => {
    setCreatures([...creatures, { ...creature, id: Date.now() }]);
  };

  const handleAddCreatureToBattle = (creature) => {
    setBattleCreatures([...battleCreatures, { ...creature, id: Date.now() }]);
  };

  const handleRemoveCreature = (creatureId) => {
    setBattleCreatures(battleCreatures.filter(creature => creature.id !== creatureId));
  };

  const handleDeleteCreature = (creatureId) => {
    setCreatures(creatures.filter(creature => creature.id !== creatureId));
  };

  const handleUpdateCreature = (updatedCreature) => {
    // Update in creatures list
    setCreatures(creatures.map(creature => 
      creature.id === updatedCreature.id ? updatedCreature : creature
    ));
    
    // Update in battleCreatures list if it exists there
    setBattleCreatures(battleCreatures.map(creature => 
      creature.id === updatedCreature.id ? updatedCreature : creature
    ));
  };

  const handleAddPlayer = (player) => {
    setPlayers([...players, { ...player, id: Date.now() }]);
  };

  const handleDeletePlayer = (playerId) => {
    setPlayers(players.filter(p => p.id !== playerId));
  };

  const handleUpdatePlayer = (playerId, updatedData) => {
    setPlayers(players.map(player => 
      player.id === playerId ? { ...player, ...updatedData } : player
    ));
  };

  const handleStartBattle = () => {
    // Only use participants that are already in battleParticipants
    const allParticipants = battleParticipants.map(participant => ({
      ...participant,
      type: participant.type || (participant.hp ? 'creature' : 'player')
    }));
    
    if (allParticipants.length === 0) {
      alert('Please add at least one participant to start the battle.');
      return;
    }

    setBattleStarted(true);
    setCurrentRound(1);
    // Clear previous battle state
    setBattleParticipants([]);
    setCurrentTurn(null);
    
    setRemainingParticipants(allParticipants);
    setInitiativeDialogOpen(true);
  };

  const handleEndBattle = () => {
    setBattleStarted(false);
    setCurrentTurn(null);
    setBattleParticipants([]);
    setCurrentRound(1);
  };

  const handleInitiativeConfirm = (initiative) => {
    const currentParticipant = remainingParticipants[0];
    const newInitiative = Number(initiative);
    // Check for tie
    const tiedParticipants = battleParticipants.filter(p => p.initiative === newInitiative);
    if (tiedParticipants.length > 0) {
      setInitiativeTie({ participant: currentParticipant, tiedParticipants, newValue: newInitiative });
      setPendingInitiativeParticipant({ ...currentParticipant, initiative: newInitiative });
      setInitiativeDialogOpen(false);
      return;
    }
    // No tie, proceed as before
    const newParticipant = {
      ...currentParticipant,
      initiative: newInitiative,
      status: '',
      battleId: Date.now(),
      type: currentParticipant.type || 'creature',
      hp: currentParticipant.hp || 0,
      id: currentParticipant.id,
      damageInput: ''
    };
    setBattleParticipants(prevParticipants => {
      // Always just add the new participant; tie resolution is handled elsewhere
      const updatedParticipants = [...prevParticipants, newParticipant];
      if (remainingParticipants.length === 1) {
        const sorted = [...updatedParticipants].sort((a, b) => (b.initiative || 0) - (a.initiative || 0));
        if (sorted.length > 0) {
          setCurrentTurn(sorted[0].battleId);
        }
        return sorted;
      }
      return updatedParticipants;
    });
    // Move to next participant
    const nextParticipants = remainingParticipants.slice(1);
    setRemainingParticipants(nextParticipants);
    if (nextParticipants.length === 0) {
      setInitiativeDialogOpen(false);
    }
  };

  // Handler for resolving tie during start battle
  const handleResolveInitiativeTie = (firstId) => {
    if (!initiativeTie) return;
    // Find the participant to update
    const allTied = [initiativeTie.participant, ...initiativeTie.tiedParticipants];
    const selected = allTied.find(p => p.battleId === firstId);
    if (!selected) return;
    const newInitiative = initiativeTie.newValue + 1;
    // Check if new initiative is still a tie
    const otherParticipants = battleParticipants.filter(p => p.battleId !== selected.battleId);
    const stillTied = otherParticipants.filter(p => p.initiative === newInitiative);
    if (stillTied.length > 0) {
      setInitiativeTie({ participant: selected, tiedParticipants: stillTied, newValue: newInitiative, inline: initiativeTie.inline });
      setPendingInitiativeParticipant({ ...selected, initiative: newInitiative });
      return;
    }
    if (initiativeTie.inline) {
      // Inline edit: update the selected participant's initiative
      setBattleParticipants(prev => {
        const updated = prev.map(p =>
          p.battleId === selected.battleId ? { ...p, initiative: newInitiative } : p
        );
        return [...updated].sort((a, b) => (b.initiative || 0) - (a.initiative || 0));
      });
      setInitiativeTie(null);
      setPendingInitiativeParticipant(null);
      return;
    }
    // No more tie, add participant (start battle flow)
    const newParticipant = {
      ...selected,
      initiative: newInitiative,
      status: '',
      battleId: Date.now(),
      type: selected.type || 'creature',
      hp: selected.hp || 0,
      id: selected.id,
      damageInput: ''
    };
    setBattleParticipants(prevParticipants => {
      // Remove all tied participants with the same initiative value
      const allTied = [initiativeTie.participant, ...initiativeTie.tiedParticipants];
      const filtered = prevParticipants.filter(
        p => !(p.initiative === initiativeTie.newValue && allTied.some(tied => tied.battleId === p.battleId))
      );
      const updatedParticipants = [...filtered, newParticipant];
      // If the selected participant is not the pending one, add the pending participant with original initiative
      if (pendingInitiativeParticipant && selected.battleId !== pendingInitiativeParticipant.battleId) {
        const pendingParticipant = {
          ...pendingInitiativeParticipant,
          status: '',
          battleId: Date.now(),
          type: pendingInitiativeParticipant.type || 'creature',
          hp: pendingInitiativeParticipant.hp || 0,
          id: pendingInitiativeParticipant.id,
          damageInput: ''
        };
        updatedParticipants.push(pendingParticipant);
      }
      if (remainingParticipants.length === 1) {
        const sorted = [...updatedParticipants].sort((a, b) => (b.initiative || 0) - (a.initiative || 0));
        if (sorted.length > 0) {
          setCurrentTurn(sorted[0].battleId);
        }
        return sorted;
      }
      return updatedParticipants;
    });
    // Move to next participant
    const nextParticipants = remainingParticipants.slice(1);
    setRemainingParticipants(nextParticipants);
    if (nextParticipants.length === 0) {
      setInitiativeDialogOpen(false);
    }
    setInitiativeTie(null);
    setPendingInitiativeParticipant(null);
  };

  const handleInitiativeSkip = () => {
    const nextParticipants = remainingParticipants.slice(1);
    setRemainingParticipants(nextParticipants);
    
    if (nextParticipants.length === 0) {
      setInitiativeDialogOpen(false);
    }
  };

  const handleInitiativeClose = () => {
    setInitiativeDialogOpen(false);
    handleEndBattle();
  };

  const handleFinishTurn = () => {
    if (!battleParticipants.length) return;

    // Sort participants by initiative (highest first)
    const sorted = [...battleParticipants].sort((a, b) => (b.initiative || 0) - (a.initiative || 0));
    const currentIndex = sorted.findIndex(p => p.battleId === currentTurn);
    if (currentIndex === -1) {
      setCurrentTurn(sorted[0].battleId);
      return;
    }
    const nextIndex = (currentIndex + 1) % sorted.length;
    const nextTurnId = sorted[nextIndex].battleId;
    setCurrentTurn(nextTurnId);
    // Only increment round when cycling back to the first participant
    if (nextIndex === 0) {
      setCurrentRound(prev => prev + 1);
    }
    // Ensure participants stay sorted
    setBattleParticipants(sorted);
  };

  const handleUpdateCreatureHP = (creatureId, newHP) => {
    // Update in battle participants
    setBattleParticipants(prevParticipants => 
      prevParticipants.map(participant => 
        participant.id === creatureId 
          ? { ...participant, hp: newHP }
          : participant
      )
    );
    
    // Update in battle creatures
    setBattleCreatures(prevCreatures => 
      prevCreatures.map(creature => 
        creature.id === creatureId 
          ? { ...creature, hp: newHP }
          : creature
      )
    );
  };

  const handleAddToBattle = (entity) => {
    let newName = entity.name;
    if ((entity.type || (entity.hp ? 'creature' : 'player')) === 'creature') {
      // Count how many creatures with the same base name are already in battle
      const baseName = entity.name.replace(/ \d+$/, '');
      const sameNameCount = battleParticipants.filter(
        p => (p.type === 'creature') && p.name && p.name.startsWith(baseName)
      ).length;
      if (sameNameCount > 0) {
        newName = `${baseName} ${sameNameCount + 1}`;
      }
    }
    const newParticipant = {
      ...entity,
      name: newName,
      battleId: Date.now(),
      initiative: null,
      type: entity.type || (entity.hp ? 'creature' : 'player')
    };
    setBattleParticipants(prev => [...prev, newParticipant]);
  };

  const handleRemoveParticipant = (battleId) => {
    setBattleParticipants(prev => prev.filter(p => p.battleId !== battleId));
  };

  const handleRemoveAllParticipants = () => {
    setBattleParticipants([]);
  };

  const handleRemoveAllPlayers = () => {
    setBattleParticipants(prev => prev.filter(p => p.type !== 'player'));
  };

  const handleRemoveAllCreatures = () => {
    setBattleParticipants(prev => prev.filter(p => p.type !== 'creature'));
  };

  const handleRemoveAllSavedCreatures = () => {
    setBattleCreatures([]);
  };

  const handleRemoveAllSavedPlayers = () => {
    setPlayers([]);
  };

  // Update initiative and sort participants
  const handleUpdateParticipantInitiative = (battleId, newInitiative) => {
    // Find the participant being edited
    const participant = battleParticipants.find(p => p.battleId === battleId);
    // Find all other participants with the same initiative
    const tiedParticipants = battleParticipants.filter(
      p => p.battleId !== battleId && p.initiative === newInitiative
    );
    if (tiedParticipants.length > 0) {
      setInitiativeTie({ participant, tiedParticipants, newValue: newInitiative, inline: true });
      setPendingInitiativeParticipant({ ...participant, initiative: newInitiative });
      return;
    }
    // No tie, update as normal
    setBattleParticipants(prev => {
      const updated = prev.map(p => p.battleId === battleId ? { ...p, initiative: newInitiative } : p);
      return [...updated].sort((a, b) => (b.initiative || 0) - (a.initiative || 0));
    });
  };

  // Update HP for a participant in battle
  const handleUpdateParticipantHP = (battleId, newHP) => {
    setBattleParticipants(prev => prev.map(p => p.battleId === battleId ? { ...p, hp: newHP } : p));
  };

  // Update a participant in battle by battleId
  const handleUpdateBattleParticipant = (updatedParticipant) => {
    setBattleParticipants(prev => prev.map(p => p.battleId === updatedParticipant.battleId ? { ...p, ...updatedParticipant } : p));
  };

  return (
    <Container fluid className="mt-3">
      <Tab.Container activeKey={currentTab} onSelect={handleTabChange}>
        <Nav variant="tabs" className="mb-3 d-flex justify-content-center">
          <Nav.Item>
            <Nav.Link eventKey="battle">Battle</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="creatures">Creatures</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link eventKey="players">Players</Nav.Link>
          </Nav.Item>
        </Nav>

        <Tab.Content>
          <Tab.Pane eventKey="battle">
            <BattleTab
              participants={battleParticipants}
              battleStarted={battleStarted}
              currentTurn={currentTurn}
              currentRound={currentRound}
              onStartBattle={handleStartBattle}
              onFinishTurn={handleFinishTurn}
              onEndBattle={handleEndBattle}
              onRemoveParticipant={handleRemoveParticipant}
              onRemoveAllParticipants={handleRemoveAllParticipants}
              onRemoveAllPlayers={handleRemoveAllPlayers}
              onRemoveAllCreatures={handleRemoveAllCreatures}
              onUpdateParticipantInitiative={handleUpdateParticipantInitiative}
              onUpdateParticipantHP={handleUpdateParticipantHP}
              onUpdateBattleParticipant={handleUpdateBattleParticipant}
              initiativeTie={initiativeTie}
              onResolveInitiativeTie={handleResolveInitiativeTie}
            />
          </Tab.Pane>
          <Tab.Pane eventKey="creatures">
            <CreaturesTab
              savedCreatures={creatures}
              onAddCreature={handleAddCreature}
              onUpdateCreature={handleUpdateCreature}
              onDeleteCreature={handleDeleteCreature}
              onAddToBattle={handleAddToBattle}
            />
          </Tab.Pane>
          <Tab.Pane eventKey="players">
            <PlayersTab
              players={players}
              onAddPlayer={handleAddPlayer}
              onUpdatePlayer={handleUpdatePlayer}
              onDeletePlayer={handleDeletePlayer}
              onAddToBattle={handleAddToBattle}
            />
          </Tab.Pane>
        </Tab.Content>
      </Tab.Container>
      
      <InitiativeDialog
        open={initiativeDialogOpen}
        onClose={handleInitiativeClose}
        onConfirm={handleInitiativeConfirm}
        onSkip={handleInitiativeSkip}
        participant={remainingParticipants[0]}
      />

      {(initiativeTie && handleResolveInitiativeTie && initiativeTie.participant && initiativeTie.tiedParticipants) ? (
        <div className="modal show fade d-block" tabIndex="-1" role="dialog" style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Initiative Tie</h5>
                <button type="button" className="btn-close" onClick={() => handleResolveInitiativeTie(null)}></button>
              </div>
              <div className="modal-body">
                <p>
                  Multiple participants have initiative <strong>{initiativeTie.newValue}</strong>.<br />
                  Who should go first?
                </p>
                <ul>
                  {[initiativeTie.participant, ...initiativeTie.tiedParticipants].map(p => (
                    <li key={p.battleId}>
                      <Button variant="outline-primary" onClick={() => handleResolveInitiativeTie(p.battleId)}>
                        {p.name}
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="modal-footer">
                <Button variant="secondary" onClick={() => handleResolveInitiativeTie(null)}>Cancel</Button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </Container>
  );
}

export default App; 